<?php
/**
 * Russian permissions Lexicon Entries for AjaxReviews
 *
 * @package AjaxReviews
 * @subpackage lexicon
 */
$_lang['ajaxreviews_save'] = 'Permission for save/update data.';