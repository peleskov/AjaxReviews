<?php

/**
 * @package ajaxreviews
 */
class AjaxReviewsItem extends xPDOSimpleObject
{
}