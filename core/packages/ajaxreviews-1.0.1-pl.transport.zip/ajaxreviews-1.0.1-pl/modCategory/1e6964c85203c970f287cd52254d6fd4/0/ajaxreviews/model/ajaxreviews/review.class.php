<?php
class Review extends xPDOSimpleObject {}