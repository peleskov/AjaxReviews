<?php
class Rating extends xPDOSimpleObject {}