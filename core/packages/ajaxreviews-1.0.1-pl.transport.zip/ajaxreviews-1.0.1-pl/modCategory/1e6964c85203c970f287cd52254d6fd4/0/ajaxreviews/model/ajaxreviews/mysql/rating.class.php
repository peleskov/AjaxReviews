<?php
require_once (dirname(__DIR__) . '/rating.class.php');
class Rating_mysql extends Rating {}