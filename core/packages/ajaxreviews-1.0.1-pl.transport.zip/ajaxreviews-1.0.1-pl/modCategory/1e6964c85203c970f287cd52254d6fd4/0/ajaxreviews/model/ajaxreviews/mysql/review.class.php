<?php
require_once (dirname(__DIR__) . '/review.class.php');
class Review_mysql extends Review {}